# Nexus Proxy
A clean, simple unblocked games site for school
## features:
- scramjet
- its static
- easy to manage
- simple interface
